#include "ets_sys.h"
#include "user_interface.h"

void ICACHE_FLASH_ATTR
user_init(void)
{
}
